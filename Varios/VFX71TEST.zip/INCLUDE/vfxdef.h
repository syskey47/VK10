******************************************************************************
* Project...........: Visual Extend 7.0
*                     Copyright (c) Devigus Engineering AG.
*                     All Rights Reserved.
*
* Program...........: VFXDEF.H
* Author ...........: DEAG
* Created...........: January 2001
* Version...........: 07.00.000
*
* Description.......:
* Calling Samples...:
* Parameter List....:
* Major change list.:
*

#DEFINE _VFX_HOMEDIR                 ""

#define ID_LANGUAGE "ENG"

* #DEFINE ID_LANGUAGE                "ENG"
* #DEFINE ID_LANGUAGE                "FRE"
* #DEFINE ID_LANGUAGE                "GER"
* #DEFINE ID_LANGUAGE                "ITA"
* #DEFINE ID_LANGUAGE                "ESP"
* #DEFINE ID_LANGUAGE                "USR"

#IF ID_LANGUAGE = "ENG"
#DEFINE ID_NUM_SEPARATOR	","
#DEFINE ID_NUM_DECIMAL		"."
#ENDIF

#IF ID_LANGUAGE = "FRE"
#DEFINE ID_NUM_SEPARATOR	"."
#DEFINE ID_NUM_DECIMAL		","
#ENDIF

#IF ID_LANGUAGE = "GER"
#DEFINE ID_NUM_SEPARATOR	"."
#DEFINE ID_NUM_DECIMAL		","
#ENDIF

#IF ID_LANGUAGE = "ITA"
#DEFINE ID_NUM_SEPARATOR	"."
#DEFINE ID_NUM_DECIMAL		","
#ENDIF

#IF ID_LANGUAGE = "ESP"
#DEFINE ID_NUM_SEPARATOR	"."
#DEFINE ID_NUM_DECIMAL		","
#ENDIF

#IF ID_LANGUAGE = "USR"
#DEFINE ID_NUM_SEPARATOR	","
#DEFINE ID_NUM_DECIMAL		"."
#ENDIF

#DEFINE ID_WINOFFTOP                23
#DEFINE ID_WINOFFLEFT               23

#DEFINE ID_CR                       CHR(13)
#DEFINE ID_TAB                      CHR(9)
#DEFINE ID_CRLF                     CHR(13) + CHR(10)

#DEFINE ID_NORMAL_MODE              0
#DEFINE ID_EDIT_MODE                1
#DEFINE ID_INSERT_MODE              2

#DEFINE ID_ON                       "ON"
#DEFINE ID_OFF                      "OFF"

*-- Constants used to read the system registry
#DEFINE HKEY_LOCAL_MACHINE      -2147483646
#DEFINE KEY_SHARED_TOOLS_LOCATION  "Software\Microsoft\Shared Tools\MSInfo"
#DEFINE KEY_NTCURRENTVERSION       "Software\Microsoft\Windows NT\CurrentVersion"
#DEFINE KEY_WIN4CURRENTVERSION     "Software\Microsoft\Windows\CurrentVersion"
#DEFINE KEY_QUERY_VALUE        1
#DEFINE ERROR_SUCCESS        0

#DEFINE ERROR_USER_DEFINED           1098
#DEFINE ERROR_RECORD_IN_USE          1502
#DEFINE ERROR_CANT_LOCK_FILE         1503
#DEFINE ERROR_CONNECTIVITY_ERROR     1526
#DEFINE ERROR_TRIGGER_FAILED         1539
#DEFINE ERROR_CONNECTION_BUSY        1541
#DEFINE ERROR_FIELD_CANT_BE_NULL     1581
#DEFINE ERROR_FIELD_RULE_VIOLATED    1582
#DEFINE ERROR_RECORD_RULE_VIOLATED   1583
#DEFINE ERROR_UPDATE_CONFLICT        1585
#DEFINE ERROR_MULTI_UPDATE_CONFLICT  1595
#DEFINE ERROR_UNIQUE_INDEX_VIOLATED  1884
#DEFINE ERROR_DE_ALREADY_UNLOADED    1967

#DEFINE KEY_SHIFT                       1
#DEFINE KEY_HOME                        1
#DEFINE KEY_CONTROL                     2
#DEFINE KEY_PAGEDOWN                    3
#DEFINE KEY_PGDOWN                      3
#DEFINE KEY_ALT                         4
#DEFINE KEY_RIGHT                       5
#DEFINE KEY_UP                          5
#DEFINE KEY_END                         6
#DEFINE KEY_DELETE                      7
#DEFINE KEY_TAB                         9
#DEFINE KEY_F9                         -8
#DEFINE KEY_RETURN                     13
#DEFINE KEY_CARRIAGERETURN             13
#DEFINE KEY_CR                         13
#DEFINE KEY_ENTER                      13
#DEFINE KEY_SHIFTTAB                   15
#DEFINE KEY_PGUP                       18
#DEFINE KEY_PAGEUP                     18
#DEFINE KEY_LEFT                       19
#DEFINE KEY_INSERT                     22
#DEFINE KEY_CTRLEND                    23
#DEFINE KEY_DOWN                       24
#DEFINE KEY_ESCAPE                     27
#DEFINE KEY_CTRLHOME                   29
#DEFINE KEY_SPACE                      32
#DEFINE KEY_EXCLAMATION                33
#DEFINE KEY_DOUBLEQUOTE                34
#DEFINE KEY_POUND                      35
#DEFINE KEY_DOLLAR                     36
#DEFINE KEY_PERCENT                    37
#DEFINE KEY_AMPERSAND                  38
#DEFINE KEY_SINGLEQUOTE                39
#DEFINE KEY_LEFTPAREN                  40
#DEFINE KEY_RIGHTPAREN                 41
#DEFINE KEY_STAR                       42
#DEFINE KEY_ASTERISK                   42
#DEFINE KEY_PLUS                       43
#DEFINE KEY_COMMA                      44
#DEFINE KEY_DASH                       45
#DEFINE KEY_MINUS                      45
#DEFINE KEY_PERIOD                     46
#DEFINE KEY_FORWARDSLASH               47
#DEFINE KEY_SLASH                      47
#DEFINE KEY_0                          48
#DEFINE KEY_ZERO                       48
#DEFINE KEY_SHIFTEND                   49
#DEFINE KEY_ONE                        49
#DEFINE KEY_1                          49
#DEFINE KEY_2                          50
#DEFINE KEY_TWO                        50
#DEFINE KEY_3                          51
#DEFINE KEY_SHIFTPGDOWN                51
#DEFINE KEY_SHIFTPAGEDOWN              51
#DEFINE KEY_THREE                      51
#DEFINE KEY_FOUR                       52
#DEFINE KEY_4                          52
#DEFINE KEY_5                          53
#DEFINE KEY_FIVE                       53
#DEFINE KEY_SIX                        54
#DEFINE KEY_6                          54
#DEFINE KEY_SHIFTHOME                  55
#DEFINE KEY_7                          55
#DEFINE KEY_SEVEN                      55
#DEFINE KEY_8                          56
#DEFINE KEY_EIGHT                      56
#DEFINE KEY_SHIFTPAGEUP                57
#DEFINE KEY_9                          57
#DEFINE KEY_SHIFTPGUP                  57
#DEFINE KEY_NINE                       57
#DEFINE KEY_COLON                      58
#DEFINE KEY_SEMICOLON                  59
#DEFINE KEY_LESSTHAN                   60
#DEFINE KEY_EQUAL                      61
#DEFINE KEY_GREATERTHAN                62
#DEFINE KEY_QUESTION                   63
#DEFINE KEY_AT                         64
#DEFINE KEY_LEFTSQUARE                 91
#DEFINE KEY_BACKSLASH                  92
#DEFINE KEY_RIGHTSQUARE                93
#DEFINE KEY_CARET                      94
#DEFINE KEY_UNDERSCORE                 95
#DEFINE KEY_TICK                       96
#DEFINE KEY_LEFTCURL                  123
#DEFINE KEY_BAR                       124
#DEFINE KEY_RIGHTCURL                 125
#DEFINE KEY_TILDE                     126
#DEFINE KEY_BACKSPACE                 127
#DEFINE KEY_ALTHOME                   151
#DEFINE KEY_ALTEND                    159