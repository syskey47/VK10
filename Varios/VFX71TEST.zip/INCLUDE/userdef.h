******************************************************************************
* Project...........: Visual Extend 6.0
*                     Copyright (c) Devigus Engineering AG.
*                     All Rights Reserved.
*
* Program...........: USERDEF.H
* Author ...........: DEAG
* Created...........: July 1998
* Version...........: 06.00.000
*
* Description.......:
* Calling Samples...:
* Parameter List....:
* Major change list.:
*

#define DATABASE_LOC "VFXTEST.DBC"

#define DATAPATH_LOC "DATA"


#define MAINICON_LOC 	"BITMAP\MAIN.ICO"
#define INTROFORM_LOC	"BITMAP\INTRO.BMP"
#define DESKTOP_LOC		"BITMAP\DESKTOP.BMP"
