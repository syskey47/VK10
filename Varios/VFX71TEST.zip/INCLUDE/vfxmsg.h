******************************************************************************
* Project...........: Visual Extend 6.0
*                     Copyright (c) Devigus Engineering AG.
*                     All Rights Reserved.
*
* Program...........: VFXMSG.H
* Author ...........: DEAG
* Created...........: July 1998
* Version...........: 06.00.000
*
* Description.......:
* Calling Samples...:
* Parameter List....:
* Major change list.:
*

**__VFX_HEADER ** 04/07/2001 08:28:14 PM

#define MSG_APPEND                                "Append data to"
#define MSG_ASKSYNCH                              "Do you want to check the entries in the table vfxsysid"+CHR(13)+"and resynch them if necessary?"
#define MSG_ASK_DELETE                            "Do you want to delete this record ?"
#define MSG_ASK_FOR_IDX                           "This operation may take a long time."+CHR(13)+"Would you like to continue ?"
#define MSG_ASK_FOR_PICK                          "Wrong Input!"+CHR(13)+"Do you want to call the pick list?"
#define MSG_ASK_TO_EXIT                           "Do you want to quit the application ?"
#define MSG_ASK_TO_SAVE                           "Do you want to save this record?"
#define MSG_ATTENTION                             "Attention"
#define MSG_AUDIT                                 "Audit-Trail"
#define MSG_BAD_INPUT                             "Value not valid"
#define MSG_CANNOTFINDREPORT                      "Cannot find Report"
#define MSG_CANNOTFINDTABLE                       "Cannot find Table"
#define MSG_CANT_DELETE                           "You can't delete this record"
#define MSG_CANT_EDIT                             "You can't edit this record"
#define MSG_CANT_INSERT                           "You can't insert new record"
#define MSG_CLEAR_IDX                             "Deleting temporary index"
#define MSG_CLEAR_RESOURCE                        "Do you want to clear the user's resources ?"
#define MSG_CLOSEOUTLOOK                          "Closing Outlook. Please wait..."
#define MSG_CONTACTADMIN                          "If you can't fix this error message by correcting your input"+CHR(13)+"please contact your system administrator!"
#define MSG_COPYING                               "Copying:"
#define MSG_DATABASE_NOT_FOUND                    "Database not found"
#define MSG_DELETE                                "Delete temporary files..."
#define MSG_DELETEREPORT                          "Do you want to delete this report?"
#define MSG_DONE                                  "Done"
#define MSG_EDITMODE                              "Edit -"
#define MSG_EMPTY_VIEW                            "There are no items to show in this view"
#define MSG_ENTERCLIENTNAME                       "Please enter the client name"
#define MSG_ENTERDATAPATH                         "Please enter the data path"
#define MSG_ENTERREPORTDESCRIPTION                "Please enter the new report description..."
#define MSG_ENTERVFXPATH                          "Please enter the VFX path"
#define MSG_ERRORNUM                              "Error:"
#define MSG_ERRORWRITINGTOSERVER                  "Error writing into the database!"
#define MSG_EXCELFAILED                           "Failed to open Excel."
#define MSG_EXPORTCOMPLETED                       "Export successfully completed!"
#define MSG_EXPORTISRUNNING                       "Export is running. Please wait..."
#define MSG_FATAL_ERROR                           "Fatal Error"
#define MSG_FILTER_ON                             "Filter activated"
#define MSG_GOODEVENING                           "Good evening"
#define MSG_GOODMORNING                           "Good morning"
#define MSG_HELLO                                 "Hello"
#define MSG_HEREIAM                               "Hi, I am Merlin!"
#define MSG_IDSYNCHCOMPLETED                      "ID Synch successfully completed."
#define MSG_IMPORTCOMPLETED                       "Import successfully completed!"
#define MSG_IMPORTISRUNNING                       "Import is running. Please wait..."
#define MSG_IMPORTNOTCOMPLETED                    "Attention! Import NOT successfully completed!"
#define MSG_INSERTMODE                            "New -"
#define MSG_KEYFIELD_ERROR                        "Record already exists"
#define MSG_LOGIN_ERROR                           "You entered a wrong username or password."+CHR(13)+"Do you want to retry to login?"
#define MSG_MAKE_INDEX                            "Creating temporary index ..."
#define MSG_METHOD                                "Method:"
#define MSG_NO                                    "No"
#define MSG_NOAUDIT                               "No audit data found."
#define MSG_NOCLIENT                              "No client selected."
#define MSG_NOCONNECTION                          "Connection to the database failed."+CHR(13)+"Please verify connection and try again."
#define MSG_NODATAPATH                            "No data path specified."
#define MSG_NODATATABLE                           "VFXPATH table not found."
#define MSG_NORECIPIENT                           "Recipient has not been found"
#define MSG_NOREPORTTYPE                          "No Reporttype defined for this form!"
#define MSG_NOT_AVAILABLE                         "Function not available"
#define MSG_NOT_DELETED                           "This record has not been deleted!"
#define MSG_NOT_SAVED                             "Record not saved"
#define MSG_NOUSERAVAILABLE                       "No user available."+CHR(13)+"Please add a new user first!"
#define MSG_NO_RECORD_FOUND                       "No records found"
#define MSG_OPENDOC                               "is being opened..."
#define MSG_OPENEXCEL                             "Opening Excel. Please wait..."
#define MSG_OPENEXCHANGE                          "Opening Exchange. Please wait..."
#define MSG_OPENEXCHANGEFAILED                    "Open Exchange failed!"
#define MSG_OPENOUTLOOK                           "Opening Outlook. Please wait..."
#define MSG_OPENWORD                              "Opening Word. Please wait."
#define MSG_OPERATORS                             "Equals\;Not equals\;More than\;Less than\;is blank\;Is NULL\;Contains\;In\;Between"
#define MSG_OTHERUSERREPORTS                      "--- Other User's Reports ---"
#define MSG_OUTLOOKFAILED                         "Unable to start Outlook."
#define MSG_OWNREPORTS                            "--- Own Reports ---"
#define MSG_PROGRAM_ERROR                         "Program Error"
#define MSG_RECORD_DELETED_FROM_OTHERS            "This record has been deleted by another user."
#define MSG_REFRESHID                             "Refresh ID"
#define MSG_REPORTTEMPLATES                       "--- Report Templates ---"
#define MSG_RESTORE                               "Restore saved data..."
#define MSG_RETURNTOAPP                           "Return to Application."
#define MSG_SAVINGDATA                            "Saving data..."
#define MSG_SEARCH                                "Searching"
#define MSG_SELECTEXPORTDIRECTORY                 "Select the Export Directory"
#define MSG_SELECTIMPORTDIRECTORY                 "Select the Import Directory"
#define MSG_SELECTUSERS                           "User list"
#define MSG_SERVERERROR                           "The data server returned the following error message:"
#define MSG_SERVERERROR8115                       "Numeric overflow."+CHR(13)+"Please contact your system administrator!"
#define MSG_SUPPLYFILENAME                        "Please supply a filename for Ascii Output"
#define MSG_TABLEUPDATEFAILED                     "Tableupdate failed!"
#define MSG_TABLE_LOCK_ERROR                      "Table in use by another user"
#define MSG_TEMPLATE                              "Template"
#define MSG_TEMPLATESALLUSERS                     "Templates are available to all users."
#define MSG_UNIQUEKEY                             "Unique key violation..."
#define MSG_UPDATEPATH                            "Please enter the update path"
#define MSG_UPDATE_CONFLICT                       "Update Conflict"
#define MSG_UPDATE_RUNNING                        "Update is running ..."
#define MSG_UPDATING                              "Updating:"
#define MSG_USER_CHANGED_DATA                     "Data changed by another user."+CHR(13)+"Do you want to save anyway?"
#define MSG_USR_LEVEL_CHANGE                      "CAUTION: You are about to change the security level."+CHR(13)+"After having decreased your security level, you won't be able"+CHR(13)+"to increase it again. Are you sure you want to continue?"
#define MSG_USR_LEVEL_DOWN                        "It's not possibile to decrease the user level"
#define MSG_VFXSYSIDNOTEXCL                       "Unable to open VFXSYSID exclusively"
#define MSG_WINDOWS_OPENED                        "Some windows are open."+CHR(13)+"Close all windows and try again."
#define MSG_WORDCANNOTACTIVATE                    "Cannot activate document"
#define MSG_WORDCANNOTOPEN                        "Cannot open document"
#define MSG_WORDDOCNOTOPEN                        "Document not open"
#define MSG_WORDNOTRUNNING                        "Word is no longer active or no document is open!"
#define MSG_WORDPRINTING                          "is being printed..."
#define MSG_WORKING                               "Working ..."
#define MSG_YES                                   "Yes"

**__VFX_FOOTER **
















