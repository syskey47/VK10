******************************************************************************
* Project...........: Visual Extend 7.0
*                     Copyright (c) Devigus Engineering AG.
*                     All Rights Reserved.
*
* Program...........: USERTXT.H
* Author ...........: DEAG
* Created...........: July 1998
* Version...........: 07.00.000
*
* Description.......:
* Calling Samples...:
* Parameter List....:
* Major change list.:
*

**__VFX_HEADER ** 07/23/1997 10:00:15 PM

#define CAP_APPLICATION_TITLE                     "VFX 7.01 Build 1105 Test Application"
#define CAP_LBLCOPYRIGHTINFORMATION               "Copyright � Devigus Engineering AG."
#define CAP_LBLTHISPRODUCTISLICENSEDTO            "This product is licensed to:"
#define CAP_LBLTRADEMARKINFORMATION               "Trademark Information"
#define CAP_LBLVERSION                            "Version 0125"
#define CAP_LBLYOURAPPLICATIONNAME                "VFX Test Application"

**__VFX_FOOTER **

