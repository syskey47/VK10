******************************************************************************
* Project...........: Visual Extend 5.0
*                     Copyright (c) Devigus Engineering AG.
*                     All Rights Reserved.
*
* Program...........: USERMSG.H
* Author ...........: DEAG
* Created...........: April 1997
* Version...........: 05.00.000
*
* Description.......:
* Calling Samples...:
* Parameter List....:
* Major change list.:
*

**__VFX_HEADER ** 05/09/1997 10:06:00 AM

#define MSG_DUMMY                                 "MessageBox Dummy Text"

**__VFX_FOOTER **
