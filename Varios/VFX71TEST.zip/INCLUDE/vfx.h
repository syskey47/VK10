******************************************************************************
* Project...........: Visual Extend 7.0
*                     Copyright (c) Devigus Engineering AG.
*                     All Rights Reserved.
*
* Program...........: VFX.H
* Author ...........: DEAG
* Created...........: January 2001
* Version...........: 07.00.000
*
* Description.......:
* Calling Samples...:
* Parameter List....:
* Major change list.:
*

#INCLUDE "INCLUDE\FOXPRO.H"

#DEFINE _VFX_VERSION    "7.13.0311"

******************************************************
* REMOVE THE REMARKS FOR THE OPTIONS YOU LIKE

* #DEFINE _DEBUG_MODE		.T.
* #DEFINE _LANG_SETUP		.T.

* #DEFINE _DBCX				.T.
* #DEFINE _STONEFIELD		.T.
* #DEFINE _USE_STDLIB		.T.
******************************************************

#IFDEF _STONEFIELD
#IFNDEF _DBCX
#DEFINE _DBCX				.T.
#ENDIF
#ENDIF

#INCLUDE "INCLUDE\VFXDEF.H"
#INCLUDE "INCLUDE\VFXTXT.H"
#INCLUDE "INCLUDE\VFXMSG.H"
#INCLUDE "INCLUDE\VFXOFFCE.H"

#INCLUDE "INCLUDE\USERTXT.H"
#INCLUDE "INCLUDE\USERDEF.H"
#INCLUDE "INCLUDE\USERMSG.H"
